# Prosper Loan Data Investigation
## by Maurice Otsieno


## Dataset
This data set contains 113,937 loans with 81 variables on each loan, including loan amount, borrower rate (or interest rate), current loan status, borrower income, and many others.
The dataset can be found [here](https://s3.amazonaws.com/udacity-hosted-downloads/ud651/prosperLoanData.csv),
with dictionaryfound [here](https://docs.google.com/spreadsheets/d/1gDyi_L4UvIrLTEC6Wri5nbaMmkGmLQBk-Yx3z0XDEtI/edit#gid=0).


## Summary of Findings

I was able to verify the relationship between the 'Loan Original Amount', the 'StatedMonthlyIncome' and the 'BorrowerAPR' for the dataset given. There was no interaction between;
(i). The amont of a loan.
(ii). The stated monthly income of borrowers.
(iii) the annual percenatage rate borrowers.

More loans fall under debt consolidation listing category.
What this mean is that debt consolidation is the majority reason why people apply for loan on the prosper platform. i.e, majority of the loans are taken to repay smaller loans.

There is no relationship between monthly income and loan original amount.
What this means is that the monthly income of a person does not directly impact the amount on the loan they apply for on the prosper platform.



## Key Insights for Presentation

For the presentation, I focused on just three key Insights

1. Income Status Impact on Loan Repayment Completion.
2. Top 10 Listing Category by loan count and percentage
3. The employment category that has the higest number of completed, defaulted and chargedoff loans.
4. The relationship that exist betweeen the number of friends that invested in a loan and number of investors that are not friends.

Then, I also examined the relationship that exist between home-owner status and loan amount with the respective monthly repayment amount. I used a scatterplot to examine this relationship. I used different color palettes for each quality variable to make sure it is clear that they're different between plots.